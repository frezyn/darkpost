import { prisma } from "@workspace/database"
import { authProcedure } from "@workspace/trpc"
import { z } from "zod"


export const GetAllProvidersFromAccount = authProcedure.output({
  providers: z
}).query(async ({ ctx: { session } }) => {

  const providersConnected = prisma.account.findMany({
    where: {
      userId: session.user.id
    },
    select: {
      provider: true
    }
  })


  return providersConnected
})
