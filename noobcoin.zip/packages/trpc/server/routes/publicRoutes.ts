
import { billing } from "@workspace/billings";
import { router } from "../trpc";
import { registerUser } from "./user/register";

const user = router({
  registerUser
})

export const publicroutes = router({
  user,
  billing
})
