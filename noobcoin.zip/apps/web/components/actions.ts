"use server"
import { signOut, signIn } from "@workspace/auth"


export const SignOut = async () => {
  await signOut()
}
