
import { Dialog, DialogClose, DialogContent, DialogDescription, DialogTitle, DialogTrigger, DialogFooter, DialogHeader } from "@workspace/ui/components/dialog"
import { Button } from "@workspace/ui/components/button"
import { Label } from "@workspace/ui/components/label"
import { Input } from "@workspace/ui/components/input"
import { Dispatch, SetStateAction, useState } from "react"
import { toast } from "sonner"
import { useTRPC } from "@/utils/trpc"
import { useMutation } from "@tanstack/react-query"


export const DialogQuote = () => {
  const [quote, setQuote] = useState("")
  const [dialogQuote, setDialogQuote] = useState(false)
  const trpc = useTRPC()

  const changeQuote = useMutation(trpc.billing.changeQuote.mutationOptions({
    onSuccess: () => {
      toast(`cotacao alterada para ${quote}`)
    },
    onError: () => {
      toast(`Erro ao alterar cotacao, o que acha de tentar novamente?`)
    }
  }))

  return (
    <Dialog open={dialogQuote} onOpenChange={setDialogQuote}>
      <DialogTrigger asChild >
        <Button variant="outline" className="w-full" > Mudar cotacao </Button>
      </DialogTrigger>
      < DialogContent className="sm:max-w-[425px]" >
        <DialogHeader>
          <DialogTitle>Alterar cotacao </DialogTitle>
          <DialogDescription>
            Confirmando a cotacao nova, ela sera aplicada em tempo real.
          </DialogDescription>
        </DialogHeader>
        < div className="grid gap-4" >
          <div className="grid gap-3" >
            <Label>cotacao </Label>
            < Input id="quote" name="quote" value={quote} onChange={(e) => setQuote(e.target.value)} placeholder="ex: 1.32" />
          </div>
        </div>
        < DialogFooter >
          <DialogClose>
            <Button variant="outline">Deixa para la</Button>
          </DialogClose>
          < Button onClick={async () => {
            await changeQuote.mutateAsync({
              quote: Number(quote)
            })
            setDialogQuote(false)
          }}> Salvar alteracoes </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>

  )
}
