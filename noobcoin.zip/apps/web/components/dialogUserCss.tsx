import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@workspace/ui/components/dialog"
import { Button } from "@workspace/ui/components/button"
import { Input } from "@workspace/ui/components/input"
import { Label } from "@workspace/ui/components/label"
import { Dispatch, SetStateAction, useState } from "react"
import { toast } from "sonner"
import { useTRPC } from "@/utils/trpc"
import { useMutation } from "@tanstack/react-query"

export function DialogChangeUserCss({ setDialogUserCss }: { setDialogUserCss: Dispatch<SetStateAction<boolean>> }) {
  const [cssUserName, setCssUserName] = useState("")
  const trpc = useTRPC()


  const changeUserCss = useMutation(trpc.billing.changeUserCss.mutationOptions())


  return (
    <DialogContent className="sm:max-w-[425px]" onClick={(e) => e.stopPropagation()}>
      <DialogHeader>
        <DialogTitle>Editar nome css</DialogTitle>
        <DialogDescription>
          O nome sera usado para enviar as recargas, um nome incorreto, pode causar perda de fundos.
        </DialogDescription>
      </DialogHeader>
      <div className="grid gap-4">
        < div className="grid gap-3" >
          <Label htmlFor="name-1">Novo nome</Label>
          <Input id="name-1" name="name" onChange={(e) => setCssUserName(e.target.value)} value={cssUserName} />
        </div >
      </div >
      <DialogFooter>
        <DialogClose asChild>
          <Button variant="outline">esquece, desisti.</Button>
        </DialogClose>
        <Button type="submit" onClick={async () => {
          try {

            await changeUserCss.mutateAsync({
              newName: cssUserName
            })
            setDialogUserCss(false)
            toast("nome alterado com sucesso")
          } catch (err) {
            toast("deu erro fi, tenta dnv")
          }

        }} >Salvar</Button>
      </DialogFooter>
    </DialogContent >
  )
}

