'use client'
import { DialogContent } from "@workspace/ui/components/dialog"
import { QrCode, Copy, Check, X } from 'lucide-react'
import Image from 'next/image'
import { useState, useEffect } from 'react'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@workspace/ui/components/alert-dialog"
import { useTRPC, useTRPCClient } from "@/utils/trpc"
import { EnumStatus } from "@workspace/billings/src/api/checkPaymentStatus"



interface PaymentDialogProps {
  foreignAmount: string
  amount: string
  recipientUser: string
  qrCodeUrl: string
  pixCode: string
  status: EnumStatus,
  onClose?: () => void,
  paymentId: number
}

type EnumStatusMap = {
  [key in typeof EnumStatus[keyof typeof EnumStatus]]: any;
};

const statusConfig: EnumStatusMap = {
  pending: {
    label: 'Pendente',
    color: 'text-yellow-500',
    bgColor: 'bg-yellow-500/10',
    borderColor: 'border-yellow-500/30',
    dotColor: 'bg-yellow-500',
    description: 'Aguardando pagamento'
  },
  approved: {
    label: 'Processando',
    color: 'text-blue-500',
    bgColor: 'bg-blue-500/10',
    borderColor: 'border-blue-500/30',
    dotColor: 'bg-blue-500',
    description: 'Pagamento aprovado, enviando yuans..'

  },
  processed: {
    label: 'Concluído',
    color: 'text-green-500',
    bgColor: 'bg-green-500/10',
    borderColor: 'border-green-500/30',
    dotColor: 'bg-green-500',
    description: 'Yuans enviados! Aproveite 😄'

  },
  rejected: {
    label: 'Falhou',
    color: 'text-red-500',
    bgColor: 'bg-red-500/10',
    borderColor: 'border-red-500/30',
    dotColor: 'bg-red-500',
    description: 'Erro na transação'
  }
}


export const PaymentDialog = ({
  foreignAmount = "22.0",
  amount = "12.00",
  recipientUser = '@usuario',
  qrCodeUrl = '/qrcode-placeholder.png',
  pixCode = '00020126360014br.gov.bcb.pix0136...',
  status = EnumStatus.PENDING,
  paymentId,
  onClose
}: PaymentDialogProps) => {
  const [copied, setCopied] = useState(false)
  const [showConfirmation, setShowConfirmation] = useState(false)
  const [currentStatus, setCurrentStatus] = useState<EnumStatus>(status)
  const config = statusConfig[currentStatus]
  const trpc = useTRPCClient()

  useEffect(() => {
    const interval = setInterval(() => {
      checkPaymentStatus()
    }, 8000)

    return () => clearInterval(interval)
  }, [paymentId])

  const checkPaymentStatus = async () => {
    try {
      const data = await trpc.billing.checkPaymentStatus.query({ paymentId: paymentId })

      if (data) {
        setCurrentStatus(data?.status)

        if (data.status === EnumStatus.APPROVED) {
          return
        }
      }
    } catch (error) {
      console.error('Erro ao verificar status do pagamento:', error)
    }
  }

  const shouldShowWarning = ['pending', 'processing'].includes(currentStatus)

  const handleCopyPix = async () => {
    try {
      await navigator.clipboard.writeText(pixCode)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error('Erro ao copiar:', err)
    }
  }




  const handleCloseAttempt = () => {
    if (shouldShowWarning) {
      setShowConfirmation(true)
    } else {
      onClose?.()
    }
  }

  const handleConfirmClose = () => {
    setShowConfirmation(false)
    setCurrentStatus(EnumStatus.PENDING)
    onClose?.()
  }

  const handleCancelClose = () => {
    setShowConfirmation(false)
  }

  return (
    <>
      <DialogContent
        className="min-w-3xl border p-0 overflow-hidden [&>button]:hidden max-md:min-w-[calc(100vw-2rem)] max-md:max-w-[calc(100vw-2rem)]"
        onInteractOutside={(e) => {
          e.preventDefault()
          handleCloseAttempt()
        }}
        onEscapeKeyDown={(e) => {
          e.preventDefault()
          handleCloseAttempt()
        }}
      >
        <div className="px-8 py-6 border-b flex items-center justify-between max-md:px-4 max-md:py-4">
          <h2 className="font-semibold text-lg">Detalhes do Pagamento</h2>
          <button
            onClick={handleCloseAttempt}
            className="text-white opacity-50 hover:opacity-100 transition-opacity"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-8 py-4 max-md:px-4 overflow-y-auto max-md:max-h-[calc(100vh-200px)]">
          <div className="grid grid-cols-2 gap-12 items-start max-md:grid-cols-1 max-md:gap-6">
            <div className="space-y-8 max-md:space-y-6">
              <div className={`${config.bgColor} border ${config.borderColor} rounded-xl p-4 flex items-center gap-3`}>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <div className={`w-2 h-2 ${config.dotColor} rounded-full animate-pulse`}></div>
                    <p className={`text-sm font-semibold ${config.color}`}>{config.label}</p>
                  </div>
                  <p className="text-xs opacity-60">{config.description}</p>
                </div>
              </div>

              <div className="space-y-6 max-sm:mx-2">
                <div>
                  <p className="text-xs font-medium opacity-50 uppercase tracking-wider mb-2">Recarregando</p>
                  <p className="text-5xl font-bold">¥ {foreignAmount}</p>
                  <p className="text-sm opacity-60 mt-1">CYN</p>
                </div>

                <div>
                  <p className="text-xs font-medium opacity-50 uppercase tracking-wider mb-2">Pagando em</p>
                  <p className="text-5xl font-bold">R$ {amount}</p>
                  <p className="text-sm opacity-60 mt-1">Real Brasileiro</p>
                </div>
              </div>

              <div className="flex w-full justify-between max-md:grid max-md:grid-cols-2 max-md:gap-4 max-sm:mx-2">
                <div>
                  <p className="text-xs font-medium opacity-50 uppercase tracking-wider mb-3">Enviado para</p>
                  <div className="flex  gap-2">
                    <div className="w-2 h-2 background rounded-full"></div>
                    <p className="text-base font-medium">{recipientUser}</p>
                  </div>
                </div>

                <div>
                  <p className="text-xs font-medium opacity-50 uppercase tracking-wider mb-3">Método</p>
                  <div className="flex items-center gap-2">
                    <QrCode className="w-4 h-4 opacity-70" />
                    <p className="text-base font-medium">PIX - QR Code</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex flex-col items-center justify-center gap-8 max-md:gap-4">
              {/* QR Code Container */}
              <div className="border rounded-2xl p-6 w-full aspect-square flex items-center justify-center background/30 hover:background/50 transition-colors max-md:p-4">
                <Image
                  src={"data:image/png;base64," + qrCodeUrl}
                  alt="QR Code de Pagamento"
                  width={220}
                  height={220}
                  blurDataURL="data:image/png;base64,..."
                  className="w-auto h-auto"
                  priority
                />
              </div>

              <button
                onClick={handleCopyPix}
                className={`w-full border rounded-lg p-4 transition-all duration-300 flex items-center justify-between gap-3 font-medium max-md:p-3 ${copied
                  ? 'background/50 border-green-500/50'
                  : 'hover:border-white/50'
                  }`}
              >
                <div className="text-left flex-1 min-w-0">
                  <p className="text-xs opacity-50 uppercase tracking-wider mb-2 font-semibold">Código PIX</p>
                  <p className="text-xs font-mono break-all opacity-75 truncate">{pixCode}</p>
                </div>
                {copied ? (
                  <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                ) : (
                  <Copy className="w-5 h-5 opacity-50 flex-shrink-0 hover:opacity-100 transition-opacity" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-8 py-3 border-t background/20 max-md:px-4">
          <p className="text-xs opacity-50 text-center">
            ✓ Transação segura e protegida
          </p>
        </div>
      </DialogContent>

      {/* Confirmation Dialog */}
      <AlertDialog open={showConfirmation} onOpenChange={setShowConfirmation}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Tem certeza que deseja fechar?</AlertDialogTitle>
            <AlertDialogDescription>
              Se você fechar este modal agora, pode perder o pagamento. Confirme que deseja continuar.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="flex gap-3 justify-end">
            <AlertDialogCancel onClick={handleCancelClose}>Voltar ao pagamento</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmClose} className="bg-red-600 hover:bg-red-700">
              Fechar Modal
            </AlertDialogAction>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
