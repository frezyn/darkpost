"use client"
import React, { useState } from 'react';
import { ArrowLeftRight, ChevronDown, AlertTriangle, Search } from 'lucide-react';
import { Input } from "@workspace/ui/components/input";
import { Label } from '@workspace/ui/components/label';
import { Button } from '@workspace/ui/components/button';
import { Switch } from "@workspace/ui/components/switch"
import { Card, CardContent } from '@workspace/ui/components/card';
import { Alert, AlertDescription } from '@workspace/ui/components/alert';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@workspace/ui/components/select';
import { useTRPC } from '@/utils/trpc';
import { useMutation } from '@tanstack/react-query';
import { toast } from 'sonner';
import colors from 'tailwindcss/colors'
import { RainbowButton } from "@workspace/ui/components/rainbow-button"
import { Dialog, DialogTrigger } from '@workspace/ui/components/dialog';
import { PaymentDialog } from './dialogPayment';
import { EnumStatus } from '@workspace/billings/src/api/checkPaymentStatus';


export function SectionRecharge({ exchangeRate, userCssName, inviteCode, userPoints }: { inviteCode: string, exchangeRate: number, userCssName: string, userPoints?: number }) {
  const [fromAmount, setFromAmount] = useState('0.00');
  const [toAmount, setToAmount] = useState('');
  const [fromCurrency, setFromCurrency] = useState('BRL');
  const [toCurrency, setToCurrency] = useState('CNY');
  const [usePoints, setUsePoints] = useState(false)
  const [dialogPayment, setDialogPayment] = useState(false)
  const [qrcode, setQrcode] = useState("")
  const [pixCode, setPixCode] = useState("")
  const [paymentId, setPaymentId] = useState(0)
  const trpc = useTRPC()


  const handleAmountChange = (value: string) => {
    setFromAmount(value);
    const numValue = parseFloat(value) || 0;
    setToAmount((numValue / exchangeRate).toFixed(2));
  };

  const swapCurrencies = () => {
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
    setFromAmount(toAmount);
    setToAmount(fromAmount);
  };


  const { mutateAsync } = useMutation(trpc.billing.generatePayment.mutationOptions({
    onSuccess: ({ data }) => {
      setQrcode(data.qrcode)
      setPixCode(data.key_pix)
      setPaymentId(data.paymentId)
      setDialogPayment(true)
    },
    onError: ({ message }) => {
      toast("Erro ao criar link de pagamento", {
        position: "top-right",
        style: {
          color: colors["red"][500],
        },
        duration: 5000,
        description: message
      })
      console.error(
        "Erro ao criar o link de pagamento, o que acha de tentar novamente?",
      );
    },
  }))

  const goToCheckout = async () => {
    try {
      await mutateAsync({
        value: Number(fromAmount),
        switchState: usePoints,
      });
    } catch (err) {
      console.error(
        "tivemos um erro ao gerar o pagamento, o que acha de tentar novamente?",
      );
    }
  }


  return (
    <div className="max-w-4xl mx-auto p-3 sm:p-6 bg-card border-1 rounded-2xl min-h-fit *:data-[slot=card]:from-primary/5 *:data-[slot=card]:to-card dark:*:data-[slot=card]:bg-card">
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <Card className="bg-gradient-to-t from-primary/5 to-card dark:bg-card w-full">
          <CardContent className="p-4 sm:p-6">
            <Label className="text-gray-300 my-3 block">Você ira receber</Label>
            <div className='mb-3'>
              <div className='flex space-x-2 space-y-3 mb-3 items-center justify-center'>
                <div className="flex items-center space-x-2">
                  <div className="w-6 h-6 bg-emerald-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-xs font-bold">CY</span>
                  </div>
                </div>
                <Select value={toCurrency} disabled onValueChange={setToCurrency}>
                  <SelectTrigger className="text-white flex-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="CNY" className="text-white">CSSBUY</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="relative">
                <Input
                  type="number"
                  value={fromAmount}
                  onChange={(e) => handleAmountChange(e.target.value)}
                  className="text-white text-xl font-bold pr-16"
                  placeholder="0.00"
                />
                <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              </div>
            </div>

            <div className="bg-gradient-to-t from-primary/5 to-card border-1 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <span className="text-gray-400">CSSBUY</span>
                <div className='flex'>
                  <span className="text-emerald-400 font-mono">
                    {userCssName}
                  </span>
                </div>
              </div>
              <div className="text-white text-xl font-bold mt-1">
                ¥ {(usePoints ? Number(fromAmount) + ((userPoints || 0) * 0.01) : fromAmount) || '0.00'}
              </div>
            </div>

            <div className="text-xs text-gray-400 mx-2 mt-4">
              Taxa de câmbio: 1 {fromCurrency} = {exchangeRate} {toCurrency}
            </div>

          </CardContent>
        </Card>

        {/* Botão de troca - reposicionado para ficar horizontalmente no mobile */}
        <div className="flex items-center justify-center md:block">
          <Button
            variant="outline"
            size="icon"
            disabled
            onClick={swapCurrencies}
            className="bg-gray-800 border-gray-600 hover:bg-gray-700 text-white rounded-full h-12 w-12 transform md:transform-none rotate-90 md:rotate-0"
          >
            <ArrowLeftRight className="h-5 w-5" />
          </Button>
        </div>

        {/* To Card - 100% de largura em mobile, flex-1 em desktop */}
        <Card className="bg-gradient-to-t from-primary/5 to-card dark:bg-card w-full">
          <CardContent className="p-4 sm:p-6">
            <div className="space-y-3">
              <Label className="text-gray-300 mb-3 block">Você vai pagar</Label>
              <div className="space-y-3">
                <Select value={fromCurrency} disabled onValueChange={setFromCurrency}>
                  <SelectTrigger className="mb-3">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="BRL" className="text-white">BRL (Pix)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="bg-gradient-to-t from-primary/5 to-card border-1 rounded-lg p-3">
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Pix</span>
                </div>
                <div className="text-white text-xl font-bold mt-1">
                  R$ {toAmount || '0.00'}
                </div>
              </div>
              <div className="bg-gradient-to-t flex items-center space-x-4 from-primary/5 to-card border-1 rounded-lg p-3">
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Codigo de convite</span>
                </div>
                <div className="text-white text-sm items-center font-bold ">
                  {inviteCode || "Nenhum"}
                </div>
              </div>
            </div>
            <div className='flex w-full justify-between items-center mt-3 px-2'>
              <span className='text-xs font-bold'>Usar pontos? (minimo 2500)</span>
              <Switch checked={usePoints} onCheckedChange={() => setUsePoints((p) => !p)} />
            </div>
          </CardContent>
          {/* Convertido para um layout flex que muda para coluna em dispositivos móveis */}
        </Card>
      </div>
      <RainbowButton variant="outline" className='w-full' onClick={() => goToCheckout()}>
        CONFIRMAR
      </RainbowButton>

      {/* Warning Alert */}
      <Alert className="bg-orange-900/20 border-orange-500/50 mb-6">
        <AlertTriangle className="h-4 w-4 text-orange-500" />
        <AlertDescription className="text-orange-300 text-sm sm:text-base">
          Atenção! Verifique se o nome é correto no CSSBUY para evitar perda de fundos
        </AlertDescription>
      </Alert>

      {/* Confirm Button */}
      <Dialog open={dialogPayment}>
        <PaymentDialog paymentId={paymentId} onClose={() => setDialogPayment(false)} pixCode={pixCode} amount={toAmount} foreignAmount={fromAmount} qrCodeUrl={qrcode} recipientUser={userCssName} status={EnumStatus.PENDING} />
      </Dialog >
    </div >
  );
}
