import { IconTrendingUp } from "@tabler/icons-react"
import {
  Card,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@workspace/ui/components/card"
import { DotPattern } from "@workspace/ui/components/dot-pattern"
import { Smile } from "lucide-react"

export function SectionCards({ quote, points }: { quote: number, points: number }) {
  return (
    <div className="*:data-[slot=card]:from-primary/5 *:data-[slot=card]:to-card dark:*:data-[slot=card]:bg-card grid grid-cols-1 gap-4 px-4 *:data-[slot=card]:bg-gradient-to-t *:data-[slot=card]:shadow-xs lg:px-6 @xl/main:grid-cols-2 @5xl/main:grid-cols-2">
      <Card className="relative @container/card">
        <DotPattern className="[mask-image:radial-gradient(150px_circle_at_center,white,transparent)] opacity-30" />
        <CardHeader>
          <CardDescription>Pontos</CardDescription>
          <CardTitle className="text-2xl font-semibold tabular-nums @[250px]/card:text-3xl">
            {points}
          </CardTitle>
        </CardHeader>
        <CardFooter className="flex-col items-start gap-1.5 text-sm">
          <div className="line-clamp-1 flex gap-2 font-medium">
            Troque seus pontos por yuannnnn! <Smile className="size-4" />
          </div>
        </CardFooter>
      </Card>

      <Card className="relative @container/card">
        <DotPattern className="[mask-image:radial-gradient(150px_circle_at_center,white,transparent)] opacity-30" />
        <CardHeader>
          <CardDescription>Cotacao</CardDescription>
          <CardTitle className="text-2xl font-semibold tabular-nums @[250px]/card:text-3xl">
            {quote}
          </CardTitle>
        </CardHeader>
        <CardFooter className="flex-col items-start gap-1.5 text-sm">
          <div className="line-clamp-1 flex gap-2 font-medium">
            Cotacao atual do site <IconTrendingUp className="size-4" />
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}
