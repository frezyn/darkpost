import { Button } from "@workspace/ui/components/button"
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@workspace/ui/components/dialog"
import { Input } from "@workspace/ui/components/input"
import { Label } from "@workspace/ui/components/label"
import { Dispatch, SetStateAction, useState } from "react"
import { useTRPC } from "../utils/trpc"
import { toast } from "sonner"
import { useMutation, useQuery } from "@tanstack/react-query"

export function DialogInviteCode({ setDialogInvite }: { setDialogInvite: Dispatch<SetStateAction<boolean>> }) {
  const [inviteCode, setInviteCode] = useState<string | null>(null)
  const trpc = useTRPC()

  const generateInviteCode = useMutation(trpc.billing.GenerateInviteCode.mutationOptions({
    onSuccess: ({ data }) => {
      setInviteCode(data.invite)
    }
  }))


  const { data } = useQuery(trpc.billing.GetInviteCode.queryOptions())

  return (
    <DialogContent className="sm:max-w-[425px]">
      <DialogHeader>
        <DialogTitle>Codigo de convite</DialogTitle>
        <DialogDescription>
          Mande para um amigo, e peca para ele usa-lo. e voce ira ganhart uma % da recarga dele! :)
        </DialogDescription>
      </DialogHeader>
      <div className="grid gap-4">
        < div className="grid gap-3" >
          <Label htmlFor="name-1">Codigo de convite</Label>
          <Input readOnly className="font-bold" value={(inviteCode || data?.data.invite || "nao achei nada aqui")} />
        </div >
      </div >
      <DialogFooter>
        <DialogClose asChild>
          <Button variant="outline">esquece, desisti.</Button>
        </DialogClose>
        <Button type="submit" onClick={async () => {
          try {
            await generateInviteCode.mutateAsync()
            toast("Codigo gerado com sucesso")
          } catch (err) {
            toast("deu erro fi, tenta dnv")
          }

        }} >Gerar codigo</Button>
      </DialogFooter>
    </DialogContent >
  )
}

