"use client"

import * as React from "react"
import {
  AudioWaveform,
  BookOpen,
  Bot,
  Clock,
  Command,
  Frame,
  GalleryVerticalEnd,
  icons,
  Lock,
  Map,
  PieChart,
  Settings2,
  SquareTerminal,
  User,
} from "lucide-react"
import { NavMain } from "@/components/nav-main"
import { NavProjects } from "@/components/nav-projects"
import { NavUser } from "@/components/nav-user"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarRail,
} from "@workspace/ui/components/sidebar"
import { useSession } from "@workspace/auth"
import { title } from "process"

// This is sample data.
const data = {
  navMain: [
    {
      title: "Voce",
      url: "#",
      icon: User,
      isActive: true,
      items: [
        {
          title: "Seu nome",
        },
        {
          title: "Nick CSS"
        },
        {
          title: "Codigo Afiliado"
        },
        {
          title: "Mudar codigo de convite"
        }
      ]
    },
    {
      title: "Seguranca",
      url: "#",
      icon: Lock,
      items: [
        {
          title: "Conexoes"
        }
      ],
    },
    {
      title: "Recargas",
      url: "#",
      icon: Clock,
      items: [
        {
          title: "Historico de recargas",
          url: "#",
        },
        {
          title: "Historico de indicacao",
          url: "#",
        }
      ],
    },
  ],

}

export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  const { data: session } = useSession()

  if (!session?.user) {
    return null
  }

  return (
    <Sidebar collapsible="icon" {...props}>
      <SidebarHeader>
        <h1 className="font-bold text-center text-2xl mt-4">Configuracoes</h1>
      </SidebarHeader>
      <SidebarContent>
        {/*  <NavMain items={data.navMain} /> */}
      </SidebarContent>
      <SidebarFooter>
        <NavUser user={session.user} myInvites={[]} />
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  )
}
