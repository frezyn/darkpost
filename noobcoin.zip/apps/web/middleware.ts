import { Role } from "@prisma/client";
import { auth } from "@workspace/auth";
import { cookies } from "next/headers";
import { NextResponse } from "next/server";


const middleware = auth(async (req) => {

  const codeInvite = req.nextUrl.searchParams.get("code");
  const cookieStore = await cookies()

  if (codeInvite) {
    cookieStore.set("code", codeInvite)
  }

  const url = new URL(req.nextUrl.origin);
  if (!req.auth && !req.url.includes("login")) {
    url.pathname = "/login";
    return NextResponse.redirect(url);
  }
  if (req.auth && !req.auth.user?.userVerified && !req.url.includes("newuser")) {
    url.pathname = "/newuser";
    return NextResponse.redirect(url);
  }
  if (req.auth && req.auth.user.role === Role.Admin && !req.url.includes("admin")) {
    url.pathname = "/admin"
    return NextResponse.redirect(url)
  } if (req.auth && req.auth.user.role != Role.Admin && req.url.includes("admin")) {
    url.pathname = "/"
    return NextResponse.redirect(url, {
      status: 308
    })

  }
  return NextResponse.next();
});

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico|images/*|auth).*)"],
  unstable_allowDynamic: ["**/node_modules/@react-email*/**/*.mjs*"],
  runtime: "nodejs"
};

export default middleware
