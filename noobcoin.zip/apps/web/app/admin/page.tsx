"use client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@workspace/ui/components/card";

import { DialogQuote } from "@components/dialogQuote"
import { useState } from "react";

export default function Page() {

  return (
    <div className="flex items-center justify-center min-h-screen p-4">
      <div className="w-full max-w-md p-6 rounded-lg shadow-sm bg-card">
        <Card>
          <CardHeader>
            <CardTitle>
              Mudar cotacao
            </CardTitle>
            <CardDescription>
              simples, mas funcional.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <DialogQuote />
          </CardContent>
        </Card>
      </div>
    </div >
  )
}
