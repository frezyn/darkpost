import { webhookHandle } from "../../../../../packages/billings/src/api/webhook"

export {
  webhookHandle as POST
}
