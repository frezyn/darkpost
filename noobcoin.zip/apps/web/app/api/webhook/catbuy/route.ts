import { NextResponse } from "next/server"


export const POST = async (req: Request) => {

  if (req.method === "POST") {

    return NextResponse.json("ok", {
      status: 200
    })

  } else {
    return NextResponse.json("Method doesnt allowed", {
      status: 405
    })
  }

}
