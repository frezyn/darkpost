import { handlers } from "@workspace/auth"
export const { GET, POST } = handlers
