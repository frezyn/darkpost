import { LoginForm } from "@components/login-form"
import { BackgroundBeams } from "@workspace/ui/components/ui/background-beams"
import Image from "next/image"

export default function Page() {
  return (
    <div className=" flex min-h-svh flex-col items-center justify-center gap-6 p-6 md:p-10">
      <BackgroundBeams />
      <div className="flex w-full max-w-sm flex-col gap-6">
        <div className="flex justify-center items-center mx-auto">
          <Image src="/images/logo.png" width={100} height={100} alt="" />
        </div>
        <LoginForm />
      </div>
    </div>
  )
}
