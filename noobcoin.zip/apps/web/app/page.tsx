import { SectionCards } from "@components/section-cards"
import { SiteHeader } from "@components/site-header"
import {
  SidebarInset,
  SidebarProvider,
} from "@workspace/ui/components/sidebar"
import { Toaster } from "@workspace/ui/components/sonner"
import { auth } from "@workspace/auth"
import { SectionRecharge } from "@/components/section-recharge"
import { appRouter, createCaller } from "@workspace/trpc"



export default async function Page() {
  const session = await auth()
  const callerTrpc = createCaller(appRouter)
  const trpc = callerTrpc({ session })

  const { quote } = await trpc.billing.quoteToday()


  return (
    <SidebarProvider
      style={
        {
          "--sidebar-width": "100%", // Mobile-first approach
          "--header-height": "calc(var(--spacing) * 14)",
          "@media (min-width: 768px)": {
            "--sidebar-width": "calc(var(--spacing) * 72)",
          },
        } as React.CSSProperties
      }
    >
      <SidebarInset>
        <SiteHeader myInvites={[]} />
        <div className="flex flex-1 flex-col w-full">
          <Toaster />
          <div className="@container/main flex flex-1 flex-col gap-2 px-2 sm:px-4">
            <div className="flex flex-col gap-3 py-3 md:gap-6 md:py-6">
              <SectionCards quote={quote} points={session?.user.points!} />
            </div>
            <div className="min-w-full mt-6 md:mt-12">
              <SectionRecharge exchangeRate={quote} userCssName={session?.user.cssName!} inviteCode={session?.user.inviteCode!} userPoints={session?.user.points} />
            </div>
          </div>
        </div>
      </SidebarInset>
    </SidebarProvider >
  )
}
